# POOI-TrabajoFinal
Este proyecto se centra en abordar los desafíos de la gestión de inventarios en la industria farmacéutica, proponiendo una aplicación Java específicamente diseñada para la empresa líder en Perú, Perufarma.

# Integrantes - Grupo 7
Aliaga Lozano, Emilio,
Cotrina Carrillo, Mirko Andre,
Paucar Gutierrez, Gabriel Rodrigo,
Rodriguez Cavalier, Pedro Antonio,
Rosales Sanchez, Bryan,
Schwartz Fernández, Ethan Andre
